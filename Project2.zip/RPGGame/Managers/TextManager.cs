﻿using System;
using System.Text;
using static RPGGame.GlobalConstants;
using static RPGGame.GlobalVariables;
using static RPGGame.InventoryManager;

namespace RPGGame
{
    internal class TextManager
    {
        //This just outputs a welcome message!
        public static void Initialize()
        {
            WriteLine("                        Welcome!");
            WriteLine("            Type HELP for a list of commands!");
            WriteLine("");
        }

        public static string AddSpacesBetweenCaps(string inString)
        {
            if (string.IsNullOrWhiteSpace(inString))
                return "";
            var outString = new StringBuilder(inString.Length * 2);
            outString.Append(inString[0]);
            for (int i = 1; i < inString.Length; i++)
            {
                if (char.IsUpper(inString[i]) && inString[i - 1] != ' ')
                    outString.Append(' ');
                outString.Append(inString[i]);
            }
            return outString.ToString();
        }

        public static string ToTitleCase(string inp)
        {
            string temp = ToUpperCamelCase(inp);
            temp = AddSpacesBetweenCaps(temp);
            return temp;
        }

        public static string ToUpperCamelCase(string s)
        {
            // Check for empty string.
            if (string.IsNullOrEmpty(s))
            {
                return string.Empty;
            }
            // Return char and concat substring.
            return char.ToUpper(s[0]) + s.Substring(1);
        }

        public static void WriteLine(string inp)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write(inp);
            Console.ForegroundColor = ConsoleColor.White;
            TextQueue.Enqueue(new Line(inp, ConsoleColor.Green));
            if (TextQueue.Count > 14)
                TextQueue.Dequeue();
        }

        public static string ReadLine()
        {
            Console.ForegroundColor = ConsoleColor.White;
            string line = "";
            if (!ExternalTesting)
                line = GetInput();
            TextQueue.Enqueue(new Line(line, ConsoleColor.White));
            TextQueue.Enqueue(new Line("", ConsoleColor.White));
            if (TextQueue.Count > 15)
                TextQueue.Dequeue();
            return line;
        }

        public static void ClearCurrentConsoleLine()
        {
            int currentLineCursor = Console.CursorTop;
            Console.SetCursorPosition(0, Console.CursorTop);
            Console.Write(new string(' ', Console.WindowWidth));
            Console.SetCursorPosition(0, currentLineCursor);
        }

        public static void RenderText()
        {
            for (int i = 0; i < TextQueue.Count; i++)
            {
                Console.SetCursorPosition(0,15+i);
                ClearCurrentConsoleLine();
                Line line = TextQueue.Dequeue();
                Console.ForegroundColor = line.col;
                Console.Write(line.lineData);
                TextQueue.Enqueue(line);
            }
            Console.SetCursorPosition(0,Console.BufferHeight-1);
            ClearCurrentConsoleLine();
        }



        public static string GetInput(){
            string inp = "";
            ConsoleKey nextChar = ConsoleKey.Backspace;
            do
            {
                switch (nextChar)
                {
                    case ConsoleKey.Enter:
                        break;
                    case ConsoleKey.Spacebar:
                        inp += " ";
                        break;
                    case ConsoleKey.Backspace:
                        if (inp!="")
                        inp = inp.Substring(0,inp.Length-1);
                        Console.Write(" ");
                        Console.CursorLeft = Math.Max(0,Console.CursorLeft-1);
                        Console.Write(" ");
                        Console.CursorLeft = Math.Max(0, Console.CursorLeft - 1);
                        break;
                    default:
                        inp += nextChar.ToString();
                        break;
                }
                nextChar = Console.ReadKey().Key;
            }
            while (nextChar!= ConsoleKey.Enter);
            return inp;
        }

        public static void Write(string inp)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write(inp);
            Console.ForegroundColor = ConsoleColor.White;
        }

        public static void GoldDisplay()
        {
            WriteLine("GOLD : " + GetGold(Target));
            WriteLine(UNDERLINE + "______________________________________________________" + RESET);
        }
    }
}