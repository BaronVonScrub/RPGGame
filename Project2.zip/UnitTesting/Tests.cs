using Microsoft.VisualStudio.TestTools.UnitTesting;
using static RPGGame.GlobalVariables;
using static RPGGame.GlobalConstants;
using static RPGGame.ParseManager;
using static RPGGame.EntityManager;
using static RPGGame.InventoryManager;
using static RPGGame.CommandManager;
using static RPGGame.ConsoleManager;
using static RPGGame.CombatManager;
using RPGGame;
using System.Collections.Generic;
using System;
using System.Linq;

namespace UnitTesting
{
    [TestClass]
    public class CommandManagerTests
    {
        Entity merchant;
        List<Item> playerItemList;
        List<Item> merchantItemList;
        void DefaultSetUp()
        {
            playerItemList = CreateTestItemList();
            merchantItemList = CreateTestItemList();

            Player = EntityCreate("Human", "Player", new Coordinate(0, 0), (char)9786, 1, new Inventory("PlayerInv", playerItemList), new int[] { 1, 1, 1, 1, 1, 1 }, "This is a test entity!");
            merchant = EntityCreate("Human", "Merchant", new Coordinate(0, 0), (char)9786, 1, new Inventory("MerchantInv", merchantItemList), new int[] { 1, 1, 1, 1, 1, 1 }, "This is a test entity!");

            MainBoard = new GameBoard();
            MainBoard.AddToBoard(Player);
            MainBoard.AddToBoard(merchant);
        }

        Entity CreateTestEntity()
        {
            return EntityCreate("Entity", "Player", new Coordinate(0, 0), (char)9786, 1, GetInventory("TestInventory"), new int[] { 1, 1, 1, 1, 1, 1 }, "This is a test entity!");
        }

        Entity CreateTestHuman()
        {
            return EntityCreate("Human", "Player", new Coordinate(0, 0), (char)9786, 1, GetInventory("TestInventory"), new int[] { 1, 1, 1, 1, 1, 1 }, "This is a test entity!");
        }

        Item CreateTestItem()
        {
            return new Weapon("WEAPON attackModifier:4 damageModifier:4 minRange:2 maxRange:4 slotsNeeded:2 equipped:False name:TestItem value:15");
        }

        Item CreateExcessSlotTestItem()
        {
            Item testItem = new Weapon("WEAPON attackModifier:4 damageModifier:4 minRange:2 maxRange:4 slotsNeeded:20 equipped:False name:TestItem value:15");
            return testItem;
        }

        List<Item> CreateTestItemList()
        {
            List<Item> testItemList = new List<Item>
            {
                CreateTestItem(),
                new Gold(500)
            };
            return testItemList;
        }

        Inventory CreateTestInventoryWithItem()
        {
            return new Inventory("TestInventory", CreateTestItemList());
        }

        void ExecuteBasedOnInput(string inp)
        {
            DefaultSetUp();
            string currComm = ProcessInput(inp);
            Commands[currComm]();
        }

        [TestMethod]
        public void InitializeAll()                                          //This also initializes all necessarys statics
        {
            DefaultSetUp();
            MusicPlayer.Initialize();
            MusicPlayer.StopMusic();
            ConsoleManager.Initialize();
            TextManager.Initialize();
            ParseManager.Initialize();
            InventoryManager.Initialize();
            EntityManager.Initialize();
        }

        [TestMethod]
        public void CommandMethodsAreAllValidWhenCalledDirectly_ExcludeWhenConsoleRequired()
        {
            DefaultSetUp();
            foreach (KeyValuePair<string, Action> comm in Commands)
                comm.Value();
        }

        [TestMethod]
        public void CommandInputIsEmpty()
        {
            ExecuteBasedOnInput("");
        }

        [TestMethod]
        public void CommandInputIsBUY()
        {
            ExecuteBasedOnInput("BUY");
        }

        [TestMethod]
        public void CommandInputIsSELL()
        {
            ExecuteBasedOnInput("SELL");
        }

        [TestMethod]
        public void CommandInputIsLOOK()
        {
            ExecuteBasedOnInput("LOOK");
        }

        [TestMethod]
        public void CommandInputIsME()
        {
            ExecuteBasedOnInput("ME");
        }

        [TestMethod]
        public void CommandInputIsEXAMINE()
        {
            ExecuteBasedOnInput("EXAMINE");
        }

        [TestMethod]
        public void CommandInputIsINTERACT()
        {
            ExecuteBasedOnInput("INTERACT");
        }

        [TestMethod]
        public void CommandInputIsTALK()
        {
            ExecuteBasedOnInput("TALK");
        }

        [TestMethod]
        public void CommandInputIsQUIT()
        {
            ExecuteBasedOnInput("QUIT");
        }

        [TestMethod]
        public void CommandInputIsDEMO()
        {
            ExecuteBasedOnInput("DEMO");
        }

        [TestMethod]
        public void CommandInputIsRENAME()
        {
            ExecuteBasedOnInput("RENAME");
        }

        [TestMethod]
        public void CommandInputIsEQUIP()
        {
            ExecuteBasedOnInput("EQUIP");
        }

        [TestMethod]
        public void CommandInputIsUNEQUIP()
        {
            ExecuteBasedOnInput("UNEQUIP");
        }

        [TestMethod]
        public void CommandInputIsTAKE()
        {
            ExecuteBasedOnInput("TAKE");
        }

        [TestMethod]
        public void CommandInputIsMUTE()
        {
            ExecuteBasedOnInput("MUTE");
        }

        [TestMethod]
        public void CommandInputIsGO_NORTH()
        {
            ExecuteBasedOnInput("GO NORTH");
        }

        [TestMethod]
        public void CommandInputIsGO_SOUTH()
        {
            ExecuteBasedOnInput("GO SOUTH");
        }

        [TestMethod]
        public void CommandInputIsGO_EAST()
        {
            ExecuteBasedOnInput("GO EAST");
        }

        [TestMethod]
        public void CommandInputIsGO_WEST()
        {
            ExecuteBasedOnInput("GO WEST");
        }

        [TestMethod]
        public void CommandInputIsN()
        {
            ExecuteBasedOnInput("N");
        }

        [TestMethod]
        public void CommandInputIsS()
        {
            ExecuteBasedOnInput("S");
        }

        [TestMethod]
        public void CommandInputIsE()
        {
            ExecuteBasedOnInput("E");
        }

        [TestMethod]
        public void CommandInputIsW()
        {
            ExecuteBasedOnInput("W");
        }

        [TestMethod]
        public void CommandInputIsGIVE_ME_GOOD_GRADES()
        {
            ExecuteBasedOnInput("GIVE ME GOOD GRADES");
        }

        [TestMethod]
        public void CommandInputIsADD()
        {
            ExecuteBasedOnInput("ADD");
        }

        [TestMethod]
        public void CommandInputIsREMOVE()
        {
            ExecuteBasedOnInput("REMOVE");
        }

        [TestMethod]
        public void LookAtMeTest()
        {
            DefaultSetUp();
            LookAtMe();
        }

        [TestMethod]
        public void TradeWithTestAccessible()
        {
            Interact();
        }

        [TestMethod]
        public void TradeWithTestNotAccessible()
        {
            Input = "INTERACT Banana";
            Interact();
        }

        [TestMethod]
        public void MoveTestSuccess()
        {
            DefaultSetUp();
            Move(NORTH);
        }

        [TestMethod]
        public void MoveTestFail()
        {
            DefaultSetUp();
            MainBoard.AddToBoard(EntityCreate("Wall", "Wall", new Coordinate(0, -1), (char)1000, 1, null, new int[] { 1, 1, 1, 1, 1, 1 }, "It's a wall!"));
            Move(NORTH);
        }

        [TestMethod]
        public void TestTest()
        {
            Demo();
        }

        [TestMethod]
        public void ExamineTest()
        {
            Examine();
        }

        [TestMethod]
        public void RenameTest()
        {
            Rename();
        }

        [TestMethod]
        public void RemoveTest()
        {
            Remove();
        }

        [TestMethod]
        public void BuyTest()
        {
            Buy();
        }

        [TestMethod]
        public void SellTest()
        {
            Sell();
        }

        [TestMethod]
        public void TradeTestFromSuccess()
        {
            DefaultSetUp();
            Input = "TestItem";
            Assert.IsTrue(Trade(Player, merchant));
        }

        [TestMethod]
        public void TradeTestToSuccess()
        {
            DefaultSetUp();
            Input = "TestItem";
            Assert.IsTrue(Trade(merchant, Player));
        }

        [TestMethod]
        public void TradeTestFromFail()
        {
            DefaultSetUp();
            Input = "Potato";
            Assert.IsFalse(Trade(Player, merchant));
        }

        [TestMethod]
        public void TradeTestToFail()
        {
            DefaultSetUp();
            Input = "Potato";
            Assert.IsFalse(Trade(merchant, Player));
        }
    }

    [TestClass]
    public class EntityManagerTests
    {
        Entity testEntity;
        GameBoard testBoard;

        void CreateTestEntity()
        {
            testEntity = EntityCreate("Entity", "Player", new Coordinate(0, 0), (char)9786, 1, GetInventory("Player"), new int[] { 1, 1, 1, 1, 1, 1 }, "This is a test entity!");
        }

        void CreateTestEntityInTestBoard()
        {
            testEntity = EntityCreate("Entity", "Player", new Coordinate(0, 0), (char)9786, 1, GetInventory("Player"), new int[] { 1, 1, 1, 1, 1, 1 }, "This is a test entity!");
            testBoard = new GameBoard();
            testBoard.AddToBoard(testEntity);
        }

        [TestMethod]
        public void CreateEntityTest()
        {
            CreateTestEntity();
        }

        [TestMethod]
        public void EnemyMakeTest()
        {
            CreateTestEntityInTestBoard();
            EnemyMake(new Coordinate(0,0));
        }

        [TestMethod]
        public void CleanTest()
        {
            CreateTestEntityInTestBoard();
            CleanUp(testBoard);
        }

        [TestMethod]
        public void GetInventoryTest()
        {
            CreateTestEntity();
            Assert.IsTrue(GetInventory(testEntity) != null);
            Assert.IsTrue(GetInventory("Player") != null);
        }

        [TestMethod]
        public void ViewInventoryTest()
        {
            CreateTestEntity();
            GetCurrentInventoryList("Player");
            GetCurrentInventoryList(testEntity);
        }

        [TestMethod]
        public void GetLocalEntitiesTest()
        {
            CreateTestEntityInTestBoard();
            Assert.IsTrue(GetLocalEntities(testEntity, testBoard) != null);
            Assert.IsTrue(GetLocalEntities(testEntity, testBoard).Count != 0);
        }

    }

    [TestClass]
    public class InventoryManagerTests
    {
        Inventory testInventory;

        [TestMethod]
        public void CreateTestInventory()
        {
            testInventory = new Inventory("TestInventory");
        }

        void CreateTestInventoryInInventories()
        {
            testInventory = new Inventory("TestInventory");
            Inventories.Add(testInventory);
        }

        [TestMethod]
        public void AddInventoryTest()
        {
            CreateTestInventoryInInventories();
        }

        [TestMethod]
        public void FindInventoryTest()
        {
            CreateTestInventoryInInventories();
            GetInventory("TestInventory");
        }

        [TestMethod]
        public void ViewInventoryTest()
        {
            CreateTestInventoryInInventories();
            GetCurrentInventoryList("TestInventory");
        }

        [TestMethod]
        public void RemoveInventoryTest()
        {
            CreateTestInventoryInInventories();
            Inventories.Remove(testInventory);
        }

        [TestMethod]
        public void GenerateInventoryTest()
        {
            GenerateInv();
        }
    }

    [TestClass]
    public class ParseToolTests
    {
        void DefaultSetUp()
        {
            Player = EntityCreate("Entity", "Player", new Coordinate(0, 0), (char)9786, 1, GetInventory("TestInventory"), new int[] { 1, 1, 1, 1, 1, 1 }, "This is a test entity!");
            MainBoard = new GameBoard();
            MainBoard.AddToBoard(Player);
        }

        [TestMethod]
        public void ProcessInputTest()
        {
            ProcessInput("");
        }

        [TestMethod]
        public void GetTargetNull()
        {
            DefaultSetUp();
            GetTarget(Player, "", MainBoard);
        }

        [TestMethod]
        public void GetTargetTest()
        {
            DefaultSetUp();
            GetTarget(Player, "Player", MainBoard);
        }

        [TestMethod]
        public void GetItemTypeStringTest()
        {
            GetItemType("WEAPON");
        }

        [TestMethod]
        public void GetItemTypeNull()
        {
            GetItemType("");
        }

        [TestMethod]
        public void StripTest()
        {
            KeyListCreate();
            string testString = Strip("ADD WEAPON");
            Assert.IsTrue(testString == "");
        }

        [TestMethod]
        public void FirstUpperOnlyTest()
        {
            Assert.IsTrue(FirstUpperOnly("POTATO") == "Potato");
            Assert.IsTrue(FirstUpperOnly("potato") == "Potato");
        }

        [TestMethod]
        public void EntityFactoryValid()
        {
            EntityData testData = new EntityData(new string[] { "Player", "Entity", "9786", "99", "0 0", "TestInventory", "1 1 1 1 1 1", "This is a test entity!" });
            EntityCreate(testData);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException), "The type provided is invalid.")]
        public void EntityFactoryInvalid()
        {
            EntityData testData = new EntityData(new string[] { "Player", "POTATO", "9786", "99", "0 0", "TestInventory", "1 1 1 1 1 1", "This is a test entity!" });
            EntityCreate(testData);
        }

        [TestMethod]
        public void ItemFactoryValid()
        {
            ItemData testData = new ItemData("WEAPON attackModifier:4 equipped:False name:TestItem type:Weapon value:15");
            ItemCreate(testData);
        }

        [TestMethod]
        public void ItemFactoryInvalid()
        {
            ItemData testData = new ItemData("POTATO attackModifier:4 equipped:False name:TestItem type:Weapon value:15");
            ItemCreate(testData);
        }
    }

    [TestClass]
    public class TextToolTests { }

    [TestClass]
    public class ItemTests
    {
        Item testItem;

        void CreateTestItem()
        {
            testItem = new Weapon("WEAPON attackModifier:4 equipped:False name:TestItem type:Weapon value:15");
        }

        [TestMethod]
        public void CreateNewItemValid()
        {
            CreateTestItem();
        }

        [TestMethod]
        public void CreateNewItemInvalid()
        {
            testItem = new Weapon("potato");                        //Weapon requires "AttackModifier"
        }

        [TestMethod]
        public void CheckItemName()
        {
            CreateTestItem();
            Assert.IsTrue(testItem.Name == "TestItem");
        }

        [TestMethod]
        public void CheckItemData()
        {
            CreateTestItem();
            Assert.IsTrue(testItem.itemData.Count != 0);
        }

        [TestMethod]
        public void ExamineTest()
        {
            CreateTestItem();
            testItem.Examine();
        }
    }

    [TestClass]
    public class EntityTests
    {
        Entity testEntity;
        Item testItem;

        void CreateTestEntity()
        {
            testEntity = EntityCreate("Entity", "Player", new Coordinate(0, 0), (char)9786, 1, GetInventory("TestInventory"), new int[] { 1, 1, 1, 1, 1, 1 }, "This is a test entity!");
        }

        void CreateTestHuman()
        {
            testEntity = EntityCreate("Human", "Player", new Coordinate(0, 0), (char)9786, 1, GetInventory("TestInventory"), new int[] { 1, 1, 1, 1, 1, 1 }, "This is a test entity!");
        }

        void CreateTestWall()
        {
            testEntity = EntityCreate("Wall", "Player", new Coordinate(0, 0), (char)9786, 1, null, new int[] { 0, 0, 0, 0, 0, 0 }, "This is a test entity!");
        }

        Item CreateTestItem()
        {
            testItem = new Weapon("WEAPON attackModifier:4 damageModifier:4 minRange:2 maxRange:4 slotsNeeded:2 equipped:False name:TestItem value:15");
            return testItem;
        }

        Item CreateExcessSlotTestItem()
        {
            Item testItem = new Weapon("WEAPON attackModifier:4 damageModifier:4 minRange:2 maxRange:4 slotsNeeded:20 equipped:False name:TestItem value:15");
            return testItem;
        }

        List<Item> CreateTestItemList()
        {
            List<Item> testItemList = new List<Item>
            {
                CreateTestItem()
            };
            return testItemList;
        }

        Inventory CreateTestInventoryWithItem()
        {
            return new Inventory("TestInventory", CreateTestItemList());
        }

        void CreateTestEntityWithItem()
        {
            testEntity = EntityCreate("Human", "Player", new Coordinate(0, 0), (char)9786, 1, CreateTestInventoryWithItem(), new int[] { 1, 1, 1, 1, 1, 1 }, "This is a test entity!");
        }

        void CreateTestEntityWithItemNoSlots()
        {
            testEntity = EntityCreate("Entity", "Player", new Coordinate(0, 0), (char)9786, 1, CreateTestInventoryWithItem(), new int[] { 1, 1, 1, 1, 1, 1 }, "This is a test entity!");
        }

        List<Item> CreateTestExcessSlotItemList()
        {
            List<Item> testItemList = new List<Item>
            {
                CreateExcessSlotTestItem()
            };
            return testItemList;
        }

        Inventory CreateTestInventoryWithExcessSlotItem()
        {
            return new Inventory("TestInventory", CreateTestExcessSlotItemList());
        }

        void CreateTestEntityWithExcessSlotItem()
        {
            testEntity = EntityCreate("Human", "Player", new Coordinate(0, 0), (char)9786, 1, CreateTestInventoryWithExcessSlotItem(), new int[] { 1, 1, 1, 1, 1, 1 }, "This is a test entity!");
        }

        [TestMethod]
        public void GetViewTest()
        {
            CreateTestEntity();
            testEntity.GetView();
        }

        [TestMethod]
        public void EquipUpdateTest()
        {
            CreateTestEntity();
            testEntity.EquipUpdate();
        }

        [TestMethod]
        public void EquipValid()
        {
            CreateTestEntityWithItem();
            Assert.IsTrue(EquipToTargetByName(testEntity, "TestItem"));
        }

        [TestMethod]
        public void EquipCheckForAny()
        {
            CreateTestEntityWithItem();
            EquipToTargetByName(testEntity, "TestItem");
            Assert.IsTrue(testEntity.Equiptory["Weapon"].ToList().Exists(x => x != null));
        }

        [TestMethod]
        public void EquipCheckForSpecific()
        {
            CreateTestEntityWithItem();
            EquipToTargetByName(testEntity, "TestItem");
            Assert.IsTrue(Array.Exists(testEntity.Equiptory["Weapon"], x => (x.Name == "TestItem")));
        }

        [TestMethod]
        public void EquipMissingItem_False()
        {
            CreateTestEntityWithItem();
            Assert.IsFalse(EquipToTargetByName(testEntity, "Potato"));
        }

        [TestMethod]
        public void EquipLackingSlots_False()
        {
            CreateTestEntityWithExcessSlotItem();
            Assert.IsFalse(EquipToTargetByName(testEntity, "TestItem"));
        }

        [TestMethod]
        public void EquipNull()
        {
            CreateTestEntityWithItem();
            Assert.IsFalse(EquipToTargetByName(testEntity, ""));
        }

        public void EquipByItemNull()
        {
            CreateTestEntityWithItem();
            Assert.IsFalse(EquipToTargetByName(testEntity, ""));
        }

        [TestMethod]
        public void EquipValidByItem()
        {
            CreateTestEntityWithItem();
            Assert.IsTrue(EquipToTargetByItem(testEntity, testItem));
        }

        [TestMethod]
        public void UnquipByNameValid()
        {
            CreateTestEntityWithItem();
            EquipToTargetByName(testEntity, "TestItem");
            Assert.IsTrue(UnequipFromTargetByName(testEntity, "TestItem"));
        }

        [TestMethod]
        public void UnquipByNameInvalid()
        {
            CreateTestEntityWithItem();
            EquipToTargetByName(testEntity, "TestItem");
            Assert.IsTrue(UnequipFromTargetByName(testEntity, "TestItem"));
        }

        [TestMethod]
        public void UnquipByItemInvalid()
        {
            CreateTestEntityWithItem();
            EquipToTargetByName(testEntity, "TestItem");
            Assert.IsFalse(UnequipFromTargetByItem(testEntity, null));
        }

        [TestMethod]
        public void UnquipByItemNotEquipped()
        {
            CreateTestEntityWithItem();
            testItem.Equipped = false;
            Assert.IsFalse(UnequipFromTargetByItem(testEntity, null));
        }

        [TestMethod]
        public void UnquipByItemNoSlots()
        {
            CreateTestEntityWithItemNoSlots();
            EquipToTargetByName(testEntity, "TestItem");
            Assert.IsFalse(UnequipFromTargetByItem(testEntity, null));
        }

        [TestMethod]
        public void UnquipByItemLackingSlots()
        {
            CreateTestEntityWithItemNoSlots();
            testItem.Equipped = true;
            Assert.IsFalse(UnequipFromTargetByItem(testEntity, null));
        }

        [TestMethod]
        public void UnquipByItemValid()
        {
            CreateTestEntityWithItem();
            EquipToTargetByName(testEntity, "TestItem");
            Assert.IsTrue(UnequipFromTargetByItem(testEntity, testItem));
        }

        [TestMethod]
        public void CheckName()
        {
            CreateTestEntity();
            Assert.IsTrue(testEntity.Name == "Player");
        }

        [TestMethod]
        public void CheckPassiveExpectTrue()
        {
            CreateTestEntity();
            Assert.IsTrue(testEntity.Passive);
        }

        [TestMethod]
        public void CheckPassableExpectTrue()
        {
            CreateTestEntity();
            Assert.IsTrue(testEntity.Passable);
        }

        [TestMethod]
        public void CheckPassiveExpectFalse()
        {
            CreateTestWall();
            Assert.IsFalse(testEntity.Passive);
        }

        [TestMethod]
        public void CheckPassableExpectFalse()
        {
            CreateTestWall();
            Assert.IsFalse(testEntity.Passable);
        }

        [TestMethod]
        public void CheckInventName()
        {
            CreateTestEntity();
            Assert.IsTrue(testEntity.inventory.name == "TestInventory");
        }

        [TestMethod]
        public void CheckInventData()
        {
            CreateTestEntityWithItem();
            Assert.IsTrue(testEntity.inventory.inventData.Count != 0);
        }

        [TestMethod]
        public void CheckEquiptoryIsNotSlotLessWhenItIs()
        {
            CreateTestEntity();
            Assert.IsFalse(testEntity.Equiptory.Count != 0);
        }

        [TestMethod]
        public void CheckEquiptoryIsNotSlotLessWhenItIsNot()
        {
            CreateTestHuman();
            Assert.IsTrue(testEntity.Equiptory.Count != 0);
        }

        [TestMethod]
        public void CheckStats()
        {
            CreateTestEntity();
            Assert.IsTrue(testEntity.Stats.SequenceEqual(new int[] { 1, 1, 1, 1, 1, 1 }));
        }
    }

    [TestClass]
    public class InventoryTests
    {
        Inventory testInventory;

        void CreateTestInventory()
        {
            testInventory = new Inventory("TestInventory");
        }

        List<Item> CreateTestItemList()
        {
            List<Item> testItemList = new List<Item>
            {
                CreateTestItem()
            };
            return testItemList;
        }

        Item CreateTestItem()
        {
            Item testItem = new Weapon("WEAPON attackModifier:4 equipped:False name:TestItem type:Weapon value:15");
            return testItem;
        }

        void CreateTestInventoryWithItem()
        {
            testInventory = new Inventory("TestInventory", CreateTestItemList());
        }

        [TestMethod]
        public void NewEmptyInventoryTest()
        {
            CreateTestInventory();
        }


        [TestMethod]
        public void NewPopulatedInventoryTest()
        {
            CreateTestInventoryWithItem();
        }

        [TestMethod]
        public void CheckName()
        {
            CreateTestInventory();
            Assert.IsTrue(testInventory.name == "TestInventory");
        }

        [TestMethod]
        public void CheckInventData()
        {
            CreateTestInventory();
            Assert.IsTrue(testInventory.inventData != null);
        }

        [TestMethod]
        public void CheckInventDataForAnyItem_Unfound()
        {
            CreateTestInventory();
            Assert.IsFalse(testInventory.inventData.Count != 0);
        }

        [TestMethod]
        public void CheckInventDataForSpecificItem_Unfound()
        {
            CreateTestInventory();
            Assert.IsFalse(testInventory.inventData.Find(x => (x.Name == "TestItem")) != null);
        }

        [TestMethod]
        public void CheckInventDataForAnyItem_Found()
        {
            CreateTestInventoryWithItem();
            Assert.IsTrue(testInventory.inventData.Count != 0);
        }

        [TestMethod]
        public void CheckInventDataForSpecificItem_Found()
        {
            CreateTestInventoryWithItem();
            Assert.IsTrue(testInventory.inventData.Find(x => (x.Name == "TestItem")) != null);
        }
    }

    [TestClass]
    public class StructTests
    {
        [TestMethod]
        public void NewNoteValid()
        {
            new Note(100, 100);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException), "This Note should not be valid.")]
        public void NewNoteInvalid()
        {
            new Note(0, 0);
        }

        [TestMethod]
        public void NewNoteDataValid()
        {
            new NoteData("1, 840, Note_on_c, 0, 64, 80");
        }

        [TestMethod]
        [ExpectedException(typeof(FormatException), "This NoteData should not be valid.")]
        public void NewNoteDataInvalid()
        {
            new NoteData("banana");
        }

        [TestMethod]
        public void CoordinateTest()
        {
            new Coordinate(0, 0);
        }

        [TestMethod]
        public void ViewValid()
        {
            new View(new Coordinate(-1, -1), new Coordinate(1, 1));
        }
    }

    [TestClass]
    public class CombatManagerTests
    {
        Enemy testEnemy;
        void DefaultSetUp()
        {
            Player = EntityCreate("Entity", "Player", new Coordinate(0, 0), (char)9786, 1, GetInventory("TestInventory"), new int[] { 1, 1, 1, 1, 1, 1 }, "This is a test entity!");
            MainBoard = new GameBoard();
            MainBoard.AddToBoard(Player);
        }

        void CreateEnemy()
        {
            EntityData testEnemyData = new EntityData(new string[] { "Imp", "Imp", "9786", "99", "0 0", "TestInventory", "1 1 1 1 1 1", "This is a test entity!" });
            testEnemy = EntityCreate(testEnemyData);
        }

        [TestMethod]
        public void CombatTest()
        {
            DefaultSetUp();
            CreateEnemy();
            Combat(testEnemy);
        }

    }

    [TestClass]
    public class GameBoardTests
    {
        void DefaultSetUp()
        {
            Player = EntityCreate("Entity", "Player", new Coordinate(0, 0), (char)9786, 1, GetInventory("TestInventory"), new int[] { 1, 1, 1, 1, 1, 1 }, "This is a test entity!");
            MainBoard = new GameBoard();
            MainBoard.AddToBoard(Player);
        }

        [TestMethod]
        public void GameBoardRenderTest()
        {
            DefaultSetUp();
            MainBoard.RenderBoard();
        }
    }

    [TestClass]
    public class MusicPlayerTests
    {

    }

    [TestClass]
    public class ImportExportToolTests
    {

    }

    [TestClass]
    public class GlobalVariablesTests
    {

    }

    [TestClass]
    public class ConsoleManagerTests
    {
        void DefaultSetUp()
        {
            Player = EntityCreate("Entity", "Player", new Coordinate(0, 0), (char)9786, 1, GetInventory("TestInventory"), new int[] { 1, 1, 1, 1, 1, 1 }, "This is a test entity!");
            MainBoard = new GameBoard();
            MainBoard.AddToBoard(Player);
        }

        [TestMethod]
        public void RedrawTest()
        {
            DefaultSetUp();
            Redraw();
        }
    }
}
